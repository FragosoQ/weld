const config = {
	urls: {
		globeTexture: './assets/textures/earth_dark.jpg',
		pointTexture: './assets/imgs/disc.png'
	},
	sizes: {
		globe: 130,
		globeDotSize: 2
	},
	scale: {
		points: 0.025,
		markers: 0.025,
		globeScale: 1
	},
	rotation: {
		globe: 0.001
	},
	colors: {
		globeDotColor: /*'#05d5fa'*/'#50e2fc',
		globeMarkerColor: 'rgb(143, 216, 216)',
		globeMarkerGlow: 'rgb(255, 255, 255)',
		globeLines: 'rgb(255, 255, 255)',
		globeLinesDots: '#00a2e8'
	},
	display: {
		points: true,
		map: true,
		lines: true,
		markers: true,
		markerLabel: true,
		markerPoint: true
	},
	dots: {
		total: 3 // Multiple dots for better random distribution across arcs
	}
}

const elements = {
	globe: null,
	atmosphere: null,
	globePoints: null,
	lineDots: [],
	markers: [],
	markerLabel: [],
	markerPoint: [],
	lines: []
}

const textures = {
	markerLabels: []
}

const groups = {
	map: null,
	main: null,
	globe: null,
	lines: null,
	points: null,
	markers: null,
	atmosphere: null,
	lineDots: null,
}

const countries = {
	interval: 20000,
	selected: null,
	index: 0
}

const animations = {
	rotateGlobe: false
}